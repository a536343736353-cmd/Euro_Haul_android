# Data directory
Reserved for editable truck specifications, trailer definitions, cargo catalogues, city metadata and mission definitions. Add JSON or Godot Resource data here as the project grows.
