# Feature expansion — Euro Haul: Offline Truck Simulator

This update adds practical offline gameplay interfaces to the existing Godot prototype. It is an original trucking game inspired by the broad genre, not a copy of Truckers of Europe 3 code, art, branding, maps, UI, or audio.

## Added / connected in this update
- Offline freight-market panel with four selectable sample contracts.
- Fleet garage panel with fictional truck purchase and selection.
- Engine, gearbox, and tyre upgrade purchase buttons.
- Service-station panel for refuelling, repairs, and driver rest.
- Offline route planner using the project's existing local destination list.
- Fatigue, weather and navigation status refreshed in the driving HUD.
- Mission reward is claimed once when the prototype delivery is completed.
- Save data now includes owned/selected trucks, vehicle condition, company reputation, and reward state.
- HUD panel remains interactive while the game is paused.
- Project is designed for offline play; no network calls or remote services are included.

## Size target
The source ZIP is intentionally lightweight and contains no large commercial asset packs. The installed APK should remain below 700 MB if future assets are kept optimized. This is a target, not a verified APK size: an actual Android export and install-size measurement are still required.

## Still not equivalent to a commercial simulator
The project still uses procedural placeholder geometry and a small prototype road area. It does not yet include a large connected European road network, realistic articulated trailer physics, licensed high-detail trucks, full traffic AI, detailed interiors, professional sound recordings, voice navigation, dynamic economy simulation, or production-grade Android QA.

## Legal / originality
Do not use Truckers of Europe 3 proprietary assets, source code, maps, logos, sounds, or copied UI. Use original or properly licensed assets.
