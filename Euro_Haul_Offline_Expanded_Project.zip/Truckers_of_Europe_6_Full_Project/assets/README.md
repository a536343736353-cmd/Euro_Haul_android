# Assets
The project builds its prototype geometry procedurally in GDScript, so it runs without external asset downloads. Replace or supplement these primitives with original/licensed truck models, interior meshes, textures, animations and audio.
