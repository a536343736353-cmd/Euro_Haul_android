# Android export
Install the matching Godot export templates and Android build dependencies, then configure an Android export preset in Godot's Export dialog. Set a unique application ID, package signing keystore, version code and version name before release. These depend on your developer identity and cannot be pre-filled.
