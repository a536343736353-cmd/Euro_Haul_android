# Android APK build guide

This project is a Godot project. Any service that builds it must run a compatible Godot engine and Android export toolchain somewhere (locally or on a cloud server). A ZIP extractor or generic app-maker cannot convert `.tscn` and `.gd` files directly into an APK.

## Before exporting

1. Use a build service that explicitly supports the Godot version required by `project.godot` (currently marked as Godot 4.7).
2. Upload the **entire project folder**, keeping `project.godot` at its root. Do not upload only the `scenes` or `scripts` folders.
3. Confirm the service has matching Godot export templates and Android build dependencies installed.
4. Configure an Android export preset with a unique application ID, version name/code, target SDK, and ARM64 architecture.
5. For a release APK, configure signing with your own keystore. Never share your keystore password publicly.
6. Export a debug APK first, install it on the target Android device, and test startup, touch controls, saving, performance, and screen layout.
7. Only create a signed release APK after the debug build passes testing.

## Cloud-builder warning

A cloud builder may let you avoid installing Godot Editor on your phone, but it still uses the Godot engine on its server. Check the builder's supported engine versions, Android export support, upload limits, free-tier limits, and privacy policy before uploading the project. Do not assume a service is free or supports this project's exact engine version unless its current documentation confirms it.

## This archive does not contain

- A compiled APK or AAB
- Godot Android export templates
- Android SDK / build-tools / JDK
- A signing keystore
- An Android export preset

These are intentionally not fabricated or bundled here. They must be configured by the selected build environment and, for signing, by the app owner.
