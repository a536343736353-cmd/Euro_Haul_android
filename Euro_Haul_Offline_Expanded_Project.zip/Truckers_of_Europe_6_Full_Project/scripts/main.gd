extends Node3D

const TruckController = preload("res://scripts/vehicle/truck_controller.gd")
const SaveManager = preload("res://scripts/systems/save_manager.gd")
const MissionManager = preload("res://scripts/systems/mission_manager.gd")
const TrafficManager = preload("res://scripts/world/traffic_manager.gd")
const WeatherManager = preload("res://scripts/world/weather_manager.gd")
const FatigueManager = preload("res://scripts/systems/fatigue_manager.gd")
const ContractManager = preload("res://scripts/systems/contract_manager.gd")
const NavigationManager = preload("res://scripts/systems/navigation_manager.gd")
const AudioManager = preload("res://scripts/systems/audio_manager.gd")
const VehicleCatalog = preload("res://scripts/systems/vehicle_catalog.gd")
const GarageManager = preload("res://scripts/systems/garage_manager.gd")
const TrafficRules = preload("res://scripts/systems/traffic_rules.gd")
const CityBuilder = preload("res://scripts/world/city_builder.gd")
const VehicleDamage = preload("res://scripts/systems/vehicle_damage.gd")
const CompanyManager = preload("res://scripts/systems/company_manager.gd")

var truck: Node3D
var camera: Camera3D
var hud: CanvasLayer
var speed_label: Label
var gear_label: Label
var mission_label: Label
var money_label: Label
var toast_label: Label
var save_manager: Node
var missions: Node
var traffic: Node
var weather: Node
var fatigue: Node
var contracts: Node
var navigation: Node
var audio: Node
var fleet: Node
var garage: Node
var traffic_rules: Node
var vehicle_damage: Node
var company: Node
var menu_panel: PanelContainer
var fatigue_label: Label
var navigation_label: Label
var weather_label: Label
var money := 12500
var camera_mode := 0
var paused := false
var day_minutes := 8.0 * 60.0
var engine_on := true
var fuel := 420.0
var damage := 0.0

func _ready() -> void:
    _setup_environment()
    _build_world()
    var city_a:=CityBuilder.new(); add_child(city_a); city_a.build_city("Rotterdam",Vector3(38,0,-105),41)
    var city_b:=CityBuilder.new(); add_child(city_b); city_b.build_city("Hamburg",Vector3(-40,0,-205),82)
    save_manager = SaveManager.new()
    add_child(save_manager)
    missions = MissionManager.new()
    add_child(missions)
    traffic = TrafficManager.new()
    add_child(traffic)
    weather = WeatherManager.new()
    add_child(weather)
    fatigue = FatigueManager.new(); add_child(fatigue)
    contracts = ContractManager.new(); add_child(contracts)
    navigation = NavigationManager.new(); add_child(navigation)
    audio = AudioManager.new(); add_child(audio)
    fleet = VehicleCatalog.new(); add_child(fleet)
    garage = GarageManager.new(); add_child(garage)
    traffic_rules = TrafficRules.new(); add_child(traffic_rules)
    vehicle_damage = VehicleDamage.new(); add_child(vehicle_damage)
    company = CompanyManager.new(); add_child(company)
    _spawn_truck()
    _build_hud()
    _load_game()
    _show_toast("Welcome, driver. Deliver the cargo to the depot.")

func _process(delta: float) -> void:
    if paused:
        return
    day_minutes = fposmod(day_minutes + delta * 0.35, 1440.0)
    _update_clock()
    if is_instance_valid(truck):
        speed_label.text = "SPEED  %03d km/h" % int(truck.speed_kmh)
        gear_label.text = "GEAR  %s   RPM  %04d" % [truck.gear_text, int(truck.rpm)]
        money_label.text = "€ %s   FUEL %.0f L" % [str(money), fuel]
        missions.update_player_position(truck.global_position)
        mission_label.text = missions.get_status_text()
        fuel = maxf(0.0, fuel - (truck.throttle_value * delta * 0.055))
        if fuel <= 0.0:
            truck.engine_enabled = false
        fatigue.update(delta, truck.speed_kmh, truck.engine_enabled)
        fatigue_label.text = fatigue.get_status()
        weather_label.text = weather.get_description()
        navigation_label.text = navigation.get_guidance(truck.global_position)
        if missions.completed and not missions.reward_claimed:
            var reward_amount: int = missions.claim_reward()
            money += reward_amount
            if contracts.accepted and not contracts.delivered:
                contracts.complete()
                company.complete_contract()
            _show_toast("Delivery completed! Earned €%d" % reward_amount)
        if truck.global_position.y < -5.0:
            truck.global_position = Vector3(0, 1, 10)
            truck.linear_velocity = Vector3.ZERO

func _physics_process(_delta: float) -> void:
    if Input.is_action_just_pressed("camera"):
        _switch_camera()
    if Input.is_action_just_pressed("engine_toggle"):
        truck.engine_enabled = not truck.engine_enabled
        _show_toast("Engine " + ("started" if truck.engine_enabled else "stopped"))
    if Input.is_action_just_pressed("pause_game"):
        _toggle_pause()
    if Input.is_action_just_pressed("rest"):
        _rest_at_service_area()
    if Input.is_action_just_pressed("next_truck"):
        _cycle_owned_truck()

func _setup_environment() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.78, 0.9)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world_env.environment = env
    add_child(world_env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -30, 0)
    sun.light_energy = 1.2
    sun.shadow_enabled = true
    add_child(sun)

func _build_world() -> void:
    _static_box("Grassland", Vector3(0,-0.5,-70), Vector3(180,1,360), Color(0.22,0.38,0.19))
    _static_box("Main highway", Vector3(0,0,-70), Vector3(13,0.16,360), Color(0.10,0.11,0.12))
    _static_box("Shoulder L", Vector3(-7.4,0.02,-70), Vector3(1.6,0.13,360), Color(0.36,0.35,0.30))
    _static_box("Shoulder R", Vector3(7.4,0.02,-70), Vector3(1.6,0.13,360), Color(0.36,0.35,0.30))
    for z in range(-245, 110, 12):
        _visual_box("Dashed centre line", Vector3(0,0.10,z), Vector3(0.18,0.035,5.5), Color(0.92,0.86,0.63))
        _visual_box("Edge line L", Vector3(-5.95,0.10,z), Vector3(0.12,0.025,8), Color(0.86,0.86,0.82))
        _visual_box("Edge line R", Vector3(5.95,0.10,z), Vector3(0.12,0.025,8), Color(0.86,0.86,0.82))
    for side in [-1,1]:
        for z in range(-235, 100, 23):
            _visual_box("Tree trunk", Vector3(side*17,1.1,z), Vector3(0.65,2.2,0.65), Color(0.25,0.15,0.08))
            _visual_box("Tree canopy", Vector3(side*17,3.0,z), Vector3(3.8,4.0,3.8), Color(0.10,0.30,0.12))
    # Roadside buildings and service station
    _static_box("Warehouse", Vector3(25,3,-135), Vector3(23,6,18), Color(0.48,0.52,0.56))
    _visual_box("Warehouse shutter", Vector3(25,1.8,-125.8), Vector3(8,3.6,0.18), Color(0.15,0.22,0.28))
    _static_box("Fuel station shop", Vector3(-24,2,-32), Vector3(13,4,11), Color(0.72,0.70,0.62))
    _visual_box("Fuel canopy", Vector3(-24,5,-20), Vector3(17,0.5,10), Color(0.80,0.12,0.06))
    for x in [-29,-24,-19]:
        _visual_box("Fuel pump", Vector3(x,1,-22), Vector3(0.7,2,0.7), Color(0.9,0.9,0.86))
    # bridge
    _static_box("Overpass deck", Vector3(0,7,-190), Vector3(35,1,8), Color(0.42,0.43,0.44))
    _static_box("Overpass support L", Vector3(-13,3.5,-190), Vector3(1.5,7,8), Color(0.55,0.55,0.52))
    _static_box("Overpass support R", Vector3(13,3.5,-190), Vector3(1.5,7,8), Color(0.55,0.55,0.52))

func _static_box(n:String, pos:Vector3, size:Vector3, color:Color) -> void:
    var body := StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh := BoxMesh.new()
    mesh.size = size
    var visual := MeshInstance3D.new()
    visual.mesh = mesh
    visual.material_override = _mat(color)
    body.add_child(visual)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    add_child(body)

func _visual_box(n:String, pos:Vector3, size:Vector3, color:Color) -> void:
    var visual := MeshInstance3D.new()
    visual.name = n
    visual.position = pos
    var mesh := BoxMesh.new()
    mesh.size = size
    visual.mesh = mesh
    visual.material_override = _mat(color)
    add_child(visual)

func _mat(color:Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.78
    return m

func _spawn_truck() -> void:
    truck = RigidBody3D.new()
    truck.name = "PlayerTruck"
    truck.position = Vector3(0,1,12)
    truck.mass = 9500
    truck.linear_damp = 0.15
    truck.angular_damp = 3.5
    truck.set_script(TruckController)
    add_child(truck)
    _make_truck_mesh(truck)
    var col := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(2.5,2.7,7.2)
    col.shape = shape
    col.position = Vector3(0,1.4,0)
    truck.add_child(col)
    camera = Camera3D.new()
    camera.name = "DrivingCamera"
    camera.position = Vector3(0,5.2,10.5)
    camera.rotation_degrees = Vector3(-18,0,0)
    truck.add_child(camera)
    camera.current = true

func _make_truck_mesh(parent:Node3D) -> void:
    _mesh_box(parent,"Chassis",Vector3(0,0.9,1.2),Vector3(2.2,0.55,5.4),Color(0.12,0.14,0.16))
    _mesh_box(parent,"Cab",Vector3(0,2.15,-1.55),Vector3(2.55,2.75,2.8),Color(0.72,0.12,0.055))
    _mesh_box(parent,"Cab roof",Vector3(0,3.58,-1.55),Vector3(2.5,0.22,2.8),Color(0.82,0.19,0.09))
    _mesh_box(parent,"Windshield",Vector3(0,2.48,-2.98),Vector3(2.08,1.15,0.055),Color(0.10,0.20,0.25))
    _mesh_box(parent,"Front bumper",Vector3(0,0.92,-3.05),Vector3(2.6,0.42,0.35),Color(0.17,0.18,0.19))
    _mesh_box(parent,"Trailer",Vector3(0,2.15,5.0),Vector3(2.55,3.5,5.8),Color(0.78,0.79,0.78))
    _mesh_box(parent,"Left mirror",Vector3(-1.52,2.55,-2.25),Vector3(0.12,0.55,0.45),Color(0.08,0.09,0.1))
    _mesh_box(parent,"Right mirror",Vector3(1.52,2.55,-2.25),Vector3(0.12,0.55,0.45),Color(0.08,0.09,0.1))
    for x in [-1.25,1.25]:
        for z in [-2.25,0.8,2.0,4.5,5.7]:
            _mesh_cylinder(parent,"Tyre",Vector3(x,0.68,z),0.52,0.36,Color(0.025,0.03,0.035),true)
    for x in [-0.88,0.88]:
        _mesh_box(parent,"Headlamp",Vector3(x,1.15,-3.25),Vector3(0.48,0.3,0.08),Color(1.0,0.88,0.55))
    # Visible dashboard approximation inside cab
    _mesh_box(parent,"Dashboard",Vector3(0,1.95,-2.2),Vector3(1.9,0.38,0.55),Color(0.07,0.08,0.09))
    _mesh_box(parent,"Seat",Vector3(0,1.65,-0.45),Vector3(0.9,1.0,0.9),Color(0.10,0.12,0.14))

func _mesh_box(parent:Node3D,n:String,pos:Vector3,size:Vector3,color:Color) -> void:
    var mi := MeshInstance3D.new()
    mi.name=n
    var mesh:=BoxMesh.new()
    mesh.size=size
    mi.mesh=mesh
    mi.position=pos
    mi.material_override=_mat(color)
    parent.add_child(mi)

func _mesh_cylinder(parent:Node3D,n:String,pos:Vector3,radius:float,height:float,color:Color,rotate_wheel:bool=false) -> void:
    var mi:=MeshInstance3D.new()
    mi.name=n
    var mesh:=CylinderMesh.new()
    mesh.top_radius=radius
    mesh.bottom_radius=radius
    mesh.height=height
    mi.mesh=mesh
    mi.position=pos
    if rotate_wheel: mi.rotation_degrees.z=90
    mi.material_override=_mat(color)
    parent.add_child(mi)

func _build_hud() -> void:
    hud=CanvasLayer.new()
    hud.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(hud)
    var top:=ColorRect.new()
    top.position=Vector2(14,14)
    top.size=Vector2(390,130)
    top.color=Color(0.015,0.025,0.04,0.82)
    hud.add_child(top)
    speed_label=_label("SPEED 000 km/h",Vector2(28,20),30)
    gear_label=_label("GEAR N   RPM 0800",Vector2(28,62),17)
    money_label=_label("€ 12500   FUEL 420 L",Vector2(28,91),16)
    top.add_child(speed_label); top.add_child(gear_label); top.add_child(money_label)
    mission_label=_label("JOB: Deliver cargo to depot",Vector2(20,158),17)
    hud.add_child(mission_label)
    fatigue_label=_label("FATIGUE 0%",Vector2(20,184),15); hud.add_child(fatigue_label)
    navigation_label=_label("STRAIGHT  •  DEPOT  •  140 m",Vector2(20,207),15); hud.add_child(navigation_label)
    weather_label=_label("CLEAR",Vector2(20,230),15); hud.add_child(weather_label)
    var title:=_label("TRUCKERS OF EUROPE 6",Vector2(0,12),18)
    title.anchor_left=0.5; title.anchor_right=0.5
    title.offset_left=-150; title.offset_right=150
    title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    hud.add_child(title)
    _touch_button("◀",Vector2(24,-118),Vector2(90,80),"steer_left")
    _touch_button("▶",Vector2(124,-118),Vector2(90,80),"steer_right")
    _touch_button("BRAKE",Vector2(-230,-118),Vector2(100,80),"brake")
    _touch_button("GAS",Vector2(-122,-118),Vector2(100,80),"accelerate")
    _button("CAMERA",Vector2(-132,16),Vector2(112,44),_switch_camera)
    _button("ENGINE",Vector2(-132,68),Vector2(112,44),_toggle_engine)
    _button("SAVE",Vector2(-132,120),Vector2(112,44),_save_game)
    _button("PAUSE",Vector2(-132,172),Vector2(112,44),_toggle_pause)
    _button("REST",Vector2(-132,224),Vector2(112,44),_rest_at_service_area)
    _button("PAINT",Vector2(-132,276),Vector2(112,44),_change_paint)
    _button("JOBS",Vector2(-132,328),Vector2(112,44),_open_jobs)
    _button("GARAGE",Vector2(-132,380),Vector2(112,44),_open_garage)
    _button("SERVICE",Vector2(-132,432),Vector2(112,44),_open_service)
    _button("MAP",Vector2(-132,484),Vector2(112,44),_open_map)
    toast_label=_label("",Vector2(0,0),18)
    toast_label.anchor_left=0.5; toast_label.anchor_right=0.5
    toast_label.anchor_top=0.5; toast_label.anchor_bottom=0.5
    toast_label.offset_left=-250; toast_label.offset_right=250
    toast_label.offset_top=100; toast_label.offset_bottom=140
    toast_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    hud.add_child(toast_label)

func _label(text_value:String,pos:Vector2,size:int)->Label:
    var l:=Label.new()
    l.text=text_value; l.position=pos
    l.add_theme_font_size_override("font_size",size)
    l.add_theme_color_override("font_color",Color(0.96,0.97,0.98))
    return l

func _touch_button(caption:String,offset:Vector2,button_size:Vector2,action:String)->void:
    var b:=TouchScreenButton.new()
    b.name=caption
    var rect:=RectangleShape2D.new(); rect.size=button_size; b.shape=rect
    var image:=Image.create(4,4,false,Image.FORMAT_RGBA8)
    image.fill(Color(0.08,0.12,0.18,0.72))
    b.texture_normal=ImageTexture.create_from_image(image)
    b.position=Vector2(120,610)+offset
    b.action=action
    hud.add_child(b)
    var label:=_label(caption,b.position+Vector2(8,20),17)
    hud.add_child(label)

func _button(caption:String,pos:Vector2,size:Vector2,callback:Callable)->void:
    var b:=Button.new()
    b.text=caption; b.position=pos; b.size=size
    b.anchor_left=1; b.anchor_right=1
    b.pressed.connect(callback)
    hud.add_child(b)

func _switch_camera()->void:
    camera_mode=(camera_mode+1)%2
    if camera_mode==0:
        camera.position=Vector3(0,5.2,10.5)
        camera.rotation_degrees=Vector3(-18,0,0)
    else:
        camera.position=Vector3(0,2.35,-2.0)
        camera.rotation_degrees=Vector3(-3,0,0)

func _toggle_engine()->void:
    truck.engine_enabled=not truck.engine_enabled
    _show_toast("Engine "+("ON" if truck.engine_enabled else "OFF"))

func _toggle_pause()->void:
    paused=not paused
    get_tree().paused=paused
    _show_toast("Paused" if paused else "Back to driving")

func _rest_at_service_area()->void:
    if truck.speed_kmh>1.0:
        _show_toast("Stop the truck before resting")
        return
    if absf(truck.global_position.x)>34.0:
        _show_toast("Rest at a marked service area")
        return
    fatigue.rest(8.0)
    day_minutes=fposmod(day_minutes+480.0,1440.0)
    _show_toast("Rest complete. Driver refreshed")

func _change_paint()->void:
    var new_color:Color=garage.cycle_paint()
    var cab:=truck.get_node_or_null("Cab") as MeshInstance3D
    var roof:=truck.get_node_or_null("Cab roof") as MeshInstance3D
    if cab: cab.material_override=_mat(new_color)
    if roof: roof.material_override=_mat(new_color.lightened(0.12))
    _show_toast("Truck paint changed")

func _cycle_owned_truck()->void:
    var current:Dictionary=fleet.get_selected()
    _show_toast("Current fleet: %s. Visit garage to purchase other models" % current.name)

func _save_game()->void:
    save_manager.save_state({"money":money,"fuel":fuel,"day_minutes":day_minutes,"truck_position":[truck.global_position.x,truck.global_position.y,truck.global_position.z],"truck_rotation":truck.rotation.y,"engine_on":truck.engine_enabled,"mission_completed":missions.completed,"mission_reward_claimed":missions.reward_claimed,"mission_reward":missions.reward,"fatigue":fatigue.fatigue,"weather":weather.weather_name,"paint_index":garage.paint_index,"garage_upgrades":garage.upgrades,"owned_trucks":fleet.owned_ids,"selected_truck":fleet.selected_id,"contract_index":contracts.active_index,"contract_accepted":contracts.accepted,"contract_delivered":contracts.delivered,"engine_condition":vehicle_damage.engine_condition,"body_condition":vehicle_damage.body_condition,"tyre_condition":vehicle_damage.tyre_condition,"company_reputation":company.reputation})
    _show_toast("Game saved")

func _load_game()->void:
    var data:Dictionary=save_manager.load_state()
    if data.is_empty(): return
    money=int(data.get("money",money))
    fuel=float(data.get("fuel",fuel))
    day_minutes=float(data.get("day_minutes",day_minutes))
    var p:Array=data.get("truck_position",[0,1,12])
    truck.global_position=Vector3(float(p[0]),float(p[1]),float(p[2]))
    truck.rotation.y=float(data.get("truck_rotation",0.0))
    truck.engine_enabled=bool(data.get("engine_on",true))
    missions.completed=bool(data.get("mission_completed",false))
    missions.reward_claimed=bool(data.get("mission_reward_claimed",false))
    missions.reward=int(data.get("mission_reward",missions.reward))
    fatigue.fatigue=float(data.get("fatigue",0.0))
    weather.set_weather(str(data.get("weather","CLEAR")))
    garage.paint_index=int(data.get("paint_index",0))
    var saved_upgrades:Dictionary = data.get("garage_upgrades", {})
    for upgrade_key in saved_upgrades:
        if garage.upgrades.has(upgrade_key):
            garage.upgrades[upgrade_key] = int(saved_upgrades[upgrade_key])
    contracts.active_index = clampi(int(data.get("contract_index",0)), 0, ContractManager.CONTRACTS.size()-1)
    contracts.accepted = bool(data.get("contract_accepted",false))
    contracts.delivered = bool(data.get("contract_delivered",false))
    fleet.owned_ids.clear()
    for truck_id in data.get("owned_trucks", ["atlas_420"]):
        fleet.owned_ids.append(str(truck_id))
    fleet.selected_id=str(data.get("selected_truck","atlas_420"))
    vehicle_damage.engine_condition=float(data.get("engine_condition",100.0))
    vehicle_damage.body_condition=float(data.get("body_condition",100.0))
    vehicle_damage.tyre_condition=float(data.get("tyre_condition",100.0))
    company.reputation=int(data.get("company_reputation",1))

func _open_panel(title_text:String, description:String) -> VBoxContainer:
    if is_instance_valid(menu_panel):
        menu_panel.queue_free()
    menu_panel = PanelContainer.new()
    menu_panel.name = "FeaturePanel"
    menu_panel.position = Vector2(300, 82)
    menu_panel.size = Vector2(680, 555)
    menu_panel.z_index = 30
    menu_panel.process_mode = Node.PROCESS_MODE_ALWAYS
    hud.add_child(menu_panel)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 10)
    menu_panel.add_child(layout)
    var heading := Label.new()
    heading.text = title_text
    heading.add_theme_font_size_override("font_size", 26)
    layout.add_child(heading)
    var intro := Label.new()
    intro.text = description
    intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    layout.add_child(intro)
    return layout

func _panel_button(parent:VBoxContainer, caption:String, callback:Callable) -> void:
    var b := Button.new()
    b.text = caption
    b.custom_minimum_size = Vector2(0, 46)
    b.pressed.connect(callback)
    parent.add_child(b)

func _close_panel() -> void:
    if is_instance_valid(menu_panel):
        menu_panel.queue_free()
    menu_panel = null

func _open_jobs() -> void:
    var layout := _open_panel("FREIGHT MARKET", "Choose a local delivery contract. All job data is stored on this device; no internet connection is required.")
    for i in range(ContractManager.CONTRACTS.size()):
        var job:Dictionary = ContractManager.CONTRACTS[i]
        _panel_button(layout, "%s  |  %s → %s  |  €%d" % [job.cargo, job.from, job.to, int(job.reward)], _accept_contract.bind(i))
    _panel_button(layout, "CLOSE", _close_panel)

func _accept_contract(index:int) -> void:
    if contracts.accepted:
        _show_toast("Finish or reset your current contract first")
        return
    if contracts.accept(index):
        var job:Dictionary = contracts.get_active()
        navigation.target_index = clampi(index, 0, navigation.destinations.size()-1)
        missions.completed = false
        missions.reward_claimed = false
        missions.reward = int(job.reward)
        missions.distance_to_depot = 140.0
        _show_toast("Contract accepted: %s" % job.name)
        _close_panel()

func _open_garage() -> void:
    var layout := _open_panel("FLEET GARAGE", "Buy and select fictional trucks. Purchasing uses your in-game balance.")
    for truck_data in VehicleCatalog.TRUCKS:
        var truck_id:String = str(truck_data.id)
        var owned:bool = fleet.owned_ids.has(truck_id)
        var selected:bool = fleet.selected_id == truck_id
        var status:String = "SELECTED" if selected else ("OWNED — SELECT" if owned else "BUY €%d" % int(truck_data.price))
        _panel_button(layout, "%s  |  %d HP  |  %s" % [truck_data.name, int(truck_data.power), status], _garage_truck_action.bind(truck_id))
    for upgrade in ["engine", "gearbox", "tyres"]:
        _panel_button(layout, "UPGRADE %s — €%d" % [upgrade.to_upper(), garage.upgrade_cost(upgrade)], _buy_upgrade.bind(upgrade))
    _panel_button(layout, "CLOSE", _close_panel)

func _garage_truck_action(truck_id:String) -> void:
    if fleet.owned_ids.has(truck_id):
        fleet.select_truck(truck_id)
        var data:Dictionary = fleet.get_selected()
        truck.max_forward_speed = float(data.max_speed)
        var cab := truck.get_node_or_null("Cab") as MeshInstance3D
        if cab:
            cab.material_override = _mat(data.color)
        _show_toast("Selected %s" % data.name)
    else:
        var result:Dictionary = fleet.purchase(truck_id, money)
        if bool(result.ok):
            money -= int(result.cost)
            _show_toast(str(result.message))
        else:
            _show_toast(str(result.message))
    _close_panel()

func _buy_upgrade(kind:String) -> void:
    var result:Dictionary = garage.buy_upgrade(kind, money)
    if bool(result.ok):
        money -= int(result.cost)
        if kind == "engine":
            truck.engine_force *= 1.08
        elif kind == "gearbox":
            truck.max_forward_speed *= 1.04
        _show_toast(str(result.message))
    else:
        _show_toast(str(result.message))
    _close_panel()

func _open_service() -> void:
    var layout := _open_panel("SERVICE STATION", "Stop the truck before using workshop services. Refuelling and repairs work offline.")
    _panel_button(layout, "REFUEL TO 420 L — €900", _refuel_truck)
    _panel_button(layout, "REPAIR BODY & ENGINE — €1,500", _repair_truck)
    _panel_button(layout, "REST 8 HOURS", _rest_at_service_area)
    _panel_button(layout, "CLOSE", _close_panel)

func _refuel_truck() -> void:
    if truck.speed_kmh > 1.0:
        _show_toast("Stop before refuelling")
    elif fuel >= 419.0:
        _show_toast("Tank is already full")
    elif money < 900:
        _show_toast("Not enough money")
    else:
        money -= 900
        fuel = 420.0
        truck.engine_enabled = true
        _show_toast("Tank refilled")
    _close_panel()

func _repair_truck() -> void:
    if truck.speed_kmh > 1.0:
        _show_toast("Stop before repairs")
    elif money < 1500:
        _show_toast("Not enough money")
    else:
        money -= 1500
        vehicle_damage.engine_condition = 100.0
        vehicle_damage.body_condition = 100.0
        vehicle_damage.tyre_condition = 100.0
        _show_toast("Truck repaired")
    _close_panel()

func _open_map() -> void:
    var layout := _open_panel("ROUTE PLANNER", "Offline destinations currently available in the prototype region.")
    for i in range(navigation.destinations.size()):
        var destination:Dictionary = navigation.destinations[i]
        _panel_button(layout, "%s — %s" % [destination.city, destination.name], _select_destination.bind(i))
    _panel_button(layout, "CLOSE", _close_panel)

func _select_destination(index:int) -> void:
    navigation.set_target(index)
    _show_toast("Route set: %s" % navigation.get_target().name)
    _close_panel()

func _update_clock()->void:
    var hour:=int(day_minutes/60.0)
    var minute:=int(fposmod(day_minutes,60.0))
    # Sun rotation follows game time.
    for child in get_children():
        if child is DirectionalLight3D:
            child.rotation_degrees.x=-((hour-6)*15.0)-15.0

func _show_toast(message:String)->void:
    if is_instance_valid(toast_label):
        toast_label.text=message
