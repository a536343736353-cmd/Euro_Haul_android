extends Node
signal weather_changed(weather_name:String)
var weather_name:="CLEAR"
var timer:=0.0
var rain_strength:=0.0
var fog_density:=0.0
var cycle_seconds:=180.0
func _process(delta:float)->void:
 timer+=delta
 if timer>cycle_seconds:
  timer=0.0
  var choices:Array[String]=["CLEAR","CLOUDY","RAIN","FOG","STORM"]
  set_weather(choices.pick_random())
func set_weather(value:String)->void:
 weather_name=value
 rain_strength=0.85 if value in ["RAIN","STORM"] else 0.0
 fog_density=0.035 if value=="FOG" else (0.018 if value=="STORM" else 0.0)
 weather_changed.emit(weather_name)
func get_description()->String:
 return "%s  •  RAIN %.0f%%" % [weather_name,rain_strength*100.0]
