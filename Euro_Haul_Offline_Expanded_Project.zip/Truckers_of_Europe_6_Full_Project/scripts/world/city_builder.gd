extends Node3D
## Lightweight procedural roadside town modules; replace with authored city scenes for production.
func build_city(city_name:String,center:Vector3,seed_value:int=1)->void:
 var rng:=RandomNumberGenerator.new(); rng.seed=seed_value
 for i in range(12):
  var building:=MeshInstance3D.new()
  var mesh:=BoxMesh.new()
  mesh.size=Vector3(rng.randf_range(8,16),rng.randf_range(8,30),rng.randf_range(8,16))
  building.mesh=mesh
  building.position=center+Vector3(rng.randf_range(-48,48),mesh.size.y/2,rng.randf_range(-42,42))
  var mat:=StandardMaterial3D.new(); mat.albedo_color=[Color(0.55,0.58,0.61),Color(0.72,0.66,0.54),Color(0.42,0.49,0.56)].pick_random()
  building.material_override=mat
  add_child(building)
 var sign_mesh:=MeshInstance3D.new(); var sign:=BoxMesh.new(); sign.size=Vector3(9,2.4,0.3); sign_mesh.mesh=sign
 sign_mesh.position=center+Vector3(0,5,0)
 var sign_mat:=StandardMaterial3D.new(); sign_mat.albedo_color=Color(0.08,0.22,0.16); sign_mesh.material_override=sign_mat
 add_child(sign_mesh)
