extends Node3D

var traffic_cars:Array[Node3D]=[]
var spawn_timer:=0.0

func _ready()->void:
    for i in range(5):
        _spawn_car(Vector3(-3.0 if i%2==0 else 3.0,0.7,-45.0-i*42.0))

func _process(delta:float)->void:
    spawn_timer+=delta
    for car in traffic_cars:
        if not is_instance_valid(car): continue
        car.position.z+=car.get_meta("speed",8.0)*delta
        if car.position.z>35.0:
            car.position.z=-230.0
    if spawn_timer>18.0 and traffic_cars.size()<9:
        spawn_timer=0.0
        _spawn_car(Vector3(3,0.7,-230))

func _spawn_car(pos:Vector3)->void:
    var body:=Node3D.new()
    body.position=pos
    body.set_meta("speed",randf_range(5.0,12.0))
    var mesh:=MeshInstance3D.new()
    var box:=BoxMesh.new()
    box.size=Vector3(1.8,1.2,3.5)
    mesh.mesh=box
    var mat:=StandardMaterial3D.new()
    mat.albedo_color=[Color(0.15,0.25,0.65),Color(0.72,0.72,0.68),Color(0.55,0.12,0.08),Color(0.12,0.12,0.12)].pick_random()
    mesh.material_override=mat
    body.add_child(mesh)
    add_child(body)
    traffic_cars.append(body)
