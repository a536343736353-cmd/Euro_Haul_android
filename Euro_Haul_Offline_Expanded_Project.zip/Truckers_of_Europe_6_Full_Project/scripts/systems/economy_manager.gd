extends Node
var balance:=12500

func add_money(amount:int)->void:
    balance+=amount

func spend_money(amount:int)->bool:
    if amount>balance: return false
    balance-=amount
    return true
