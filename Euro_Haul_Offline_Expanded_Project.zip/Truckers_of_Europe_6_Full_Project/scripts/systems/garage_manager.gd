extends Node
var paint_index:=0
var paint_colors:Array[Color]=[Color(0.72,0.12,0.055),Color(0.08,0.28,0.68),Color(0.12,0.48,0.30),Color(0.82,0.72,0.12),Color(0.78,0.78,0.78)]
var upgrades={"engine":0,"gearbox":0,"tyres":0}
func cycle_paint()->Color:
 paint_index=(paint_index+1)%paint_colors.size()
 return paint_colors[paint_index]
func upgrade_cost(kind:String)->int:
 return 12000+int(upgrades.get(kind,0))*9000
func buy_upgrade(kind:String,balance:int)->Dictionary:
 if not upgrades.has(kind): return {"ok":false,"message":"Unknown upgrade"}
 var cost:=upgrade_cost(kind)
 if balance<cost: return {"ok":false,"message":"Insufficient funds"}
 upgrades[kind]+=1
 return {"ok":true,"cost":cost,"message":"%s upgraded" % kind.capitalize()}
