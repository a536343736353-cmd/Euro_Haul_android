extends Node
var destinations:Array[Dictionary]=[
 {"name":"Rotterdam Freight Yard","city":"Rotterdam","position":Vector3(0,0,-128)},
 {"name":"Hamburg Logistics Park","city":"Hamburg","position":Vector3(0,0,-220)},
 {"name":"Brussels Depot","city":"Brussels","position":Vector3(0,0,65)}
]
var target_index:=0
func get_target()->Dictionary: return destinations[target_index]
func set_target(index:int)->void:
 target_index=clampi(index,0,destinations.size()-1)
func distance_to(pos:Vector3)->float: return pos.distance_to(get_target().position)
func get_guidance(pos:Vector3)->String:
 var target:=get_target()
 var delta:Vector3=target.position-pos
 var direction:="STRAIGHT"
 if absf(delta.x)>8.0: direction="TURN " + ("RIGHT" if delta.x>0 else "LEFT")
 return "%s  •  %s  •  %.0f m" % [direction,target.name,delta.length()]
