extends Node
const CONTRACTS:= [
 {"name":"Food supplies","from":"Rotterdam","to":"Hamburg","cargo":"Refrigerated goods","reward":4200,"distance":420},
 {"name":"Industrial parts","from":"Brussels","to":"Cologne","cargo":"Palletised machinery","reward":3100,"distance":210},
 {"name":"Timber delivery","from":"Lyon","to":"Milan","cargo":"Timber","reward":5600,"distance":450},
 {"name":"Building materials","from":"Prague","to":"Vienna","cargo":"Construction materials","reward":2800,"distance":330}
]
var active_index:=0
var accepted:=false
var delivered:=false
func get_active()->Dictionary: return CONTRACTS[active_index]
func accept(index:int)->bool:
 if index<0 or index>=CONTRACTS.size() or accepted: return false
 active_index=index; accepted=true; delivered=false
 return true
func complete()->int:
 if not accepted or delivered: return 0
 delivered=true
 return int(get_active().reward)
func reset_job()->void:
 accepted=false; delivered=false
