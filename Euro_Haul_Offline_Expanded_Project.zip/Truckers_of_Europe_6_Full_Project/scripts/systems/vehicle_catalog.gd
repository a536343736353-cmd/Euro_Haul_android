extends Node
## Original fictional fleet catalogue. Prices are game-economy values, not real vehicles.
const TRUCKS := [
 {"id":"atlas_420","name":"Atlas 420","power":420,"price":0,"color":Color(0.72,0.12,0.055),"max_speed":31.0,"fuel_rate":0.055},
 {"id":"boreal_500","name":"Boreal 500","power":500,"price":85000,"color":Color(0.12,0.32,0.68),"max_speed":34.0,"fuel_rate":0.064},
 {"id":"continental_560","name":"Continental 560","power":560,"price":125000,"color":Color(0.16,0.48,0.32),"max_speed":36.0,"fuel_rate":0.071}
]
var owned_ids:Array[String]=["atlas_420"]
var selected_id:="atlas_420"
func get_selected()->Dictionary:
 for t in TRUCKS:
  if t.id==selected_id: return t
 return TRUCKS[0]
func purchase(id:String,balance:int)->Dictionary:
 for t in TRUCKS:
  if t.id==id:
   if owned_ids.has(id): return {"ok":false,"message":"Already owned"}
   if balance<int(t.price): return {"ok":false,"message":"Not enough money"}
   owned_ids.append(id)
   return {"ok":true,"cost":int(t.price),"message":"Purchased %s" % t.name}
 return {"ok":false,"message":"Unknown truck"}
func select_truck(id:String)->bool:
 if not owned_ids.has(id): return false
 selected_id=id
 return true
