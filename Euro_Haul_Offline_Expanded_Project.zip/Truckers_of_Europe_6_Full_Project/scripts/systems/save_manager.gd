extends Node
const SAVE_PATH="user://truckers_europe_6_save.json"

func save_state(data:Dictionary)->bool:
    var file=FileAccess.open(SAVE_PATH,FileAccess.WRITE)
    if file==null:
        push_error("Could not open save file")
        return false
    file.store_string(JSON.stringify(data))
    file.close()
    return true

func load_state()->Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var file=FileAccess.open(SAVE_PATH,FileAccess.READ)
    if file==null: return {}
    var parsed=JSON.parse_string(file.get_as_text())
    file.close()
    return parsed if parsed is Dictionary else {}
