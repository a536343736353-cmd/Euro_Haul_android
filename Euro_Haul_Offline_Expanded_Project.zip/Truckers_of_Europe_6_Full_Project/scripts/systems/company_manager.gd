extends Node
var company_name:="Northstar Haulage"
var owned_trucks:=1
var hired_drivers:=0
var reputation:=1

func hire_driver()->bool:
    if hired_drivers>=20: return false
    hired_drivers+=1
    return true

func complete_contract()->void:
    reputation+=1
