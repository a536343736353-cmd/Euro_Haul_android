extends Node
var engine_condition:=100.0
var body_condition:=100.0
var tyre_condition:=100.0

func apply_collision_damage(impact_speed:float)->void:
    var amount=clampf(impact_speed*1.7,0.0,35.0)
    body_condition=maxf(0.0,body_condition-amount)
    engine_condition=maxf(0.0,engine_condition-amount*0.22)

func repair_all(cost:int)->int:
    engine_condition=100.0
    body_condition=100.0
    tyre_condition=100.0
    return cost
