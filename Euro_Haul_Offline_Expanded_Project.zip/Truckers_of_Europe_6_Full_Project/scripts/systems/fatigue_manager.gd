extends Node
var fatigue:=0.0
var driving_hours:=0.0
var warning_level:=0
func update(delta:float,speed_kmh:float,engine_on:bool)->void:
 if engine_on and speed_kmh>2.0:
  driving_hours+=delta/3600.0
  fatigue=minf(100.0,fatigue+delta*0.0032)
 warning_level=2 if fatigue>=85.0 else (1 if fatigue>=65.0 else 0)
func rest(hours:float)->void:
 fatigue=maxf(0.0,fatigue-hours*18.0)
 driving_hours=maxf(0.0,driving_hours-hours)
func get_status()->String:
 return "FATIGUE %d%%" % int(fatigue)
