extends Node
var traffic_fines:=0
var collisions:=0
func report_collision(impact_kmh:float)->int:
 collisions+=1
 var fine:=0 if impact_kmh<12.0 else int(clampf(impact_kmh*18.0,100.0,1800.0))
 traffic_fines+=fine
 return fine
