extends Node
var capacity_litres:=600.0
var fuel_litres:=420.0
var consumption_per_second:=0.018

func update_fuel(throttle:float,delta:float)->void:
    fuel_litres=maxf(0.0,fuel_litres+(-throttle*consumption_per_second*delta))

func refuel(litres:float)->float:
    var added=minf(litres,capacity_litres-fuel_litres)
    fuel_litres+=added
    return added
