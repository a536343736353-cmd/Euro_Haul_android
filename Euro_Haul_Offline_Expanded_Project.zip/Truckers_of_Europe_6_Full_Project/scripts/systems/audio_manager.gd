extends Node
## Audio event bus. Add original/licensed AudioStream assets to the exported project to enable playback.
signal sound_event(event_name:String)
var enabled:=true
func play_event(event_name:String)->void:
 if enabled: sound_event.emit(event_name)
func set_enabled(value:bool)->void: enabled=value
