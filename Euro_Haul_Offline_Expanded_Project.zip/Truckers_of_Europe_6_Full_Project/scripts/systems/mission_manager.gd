extends Node
var completed:=false
var reward_claimed:=false
var distance_to_depot:=140.0
var reward:=2500
func update_player_position(pos:Vector3)->void:
 if completed: return
 distance_to_depot=maxf(0.0,pos.z+128.0)
 if distance_to_depot<=3.5: completed=true
func claim_reward()->int:
 if not completed or reward_claimed: return 0
 reward_claimed=true
 return reward
func get_status_text()->String:
 if completed: return "DELIVERY COMPLETED  •  Reward €%d" % reward
 return "DELIVERY: Depot ahead  •  %.0f m" % distance_to_depot
