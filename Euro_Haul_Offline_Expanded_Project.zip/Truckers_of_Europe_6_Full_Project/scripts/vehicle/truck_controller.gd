extends RigidBody3D

var speed_kmh := 0.0
var rpm := 800.0
var gear_text := "N"
var engine_enabled := true
var throttle_value := 0.0
var steering_value := 0.0
var gear := 1
var max_forward_speed := 31.0
var engine_force := 17000.0
var brake_force := 24000.0
var steer_angle := 0.42
var wheelbase := 4.0
var current_gear_ratio := 1.0

func _physics_process(delta:float)->void:
    throttle_value=Input.get_action_strength("accelerate") if engine_enabled else 0.0
    var braking=Input.get_action_strength("brake")
    steering_value=Input.get_action_strength("steer_right")-Input.get_action_strength("steer_left")
    var forward=-global_transform.basis.z
    var longitudinal=linear_velocity.dot(forward)
    speed_kmh=absf(longitudinal)*3.6
    var gear_ratios=[0.0,3.8,2.4,1.6,1.15,0.85,0.68]
    if longitudinal < -0.5:
        gear_text="R"
    else:
        gear=clampi(int(speed_kmh/22.0)+1,1,6)
        gear_text=str(gear)
    current_gear_ratio=gear_ratios[gear]
    rpm=clampf(800.0+throttle_value*2400.0+speed_kmh*current_gear_ratio*2.1,700.0,2600.0)
    if engine_enabled and longitudinal < max_forward_speed:
        apply_central_force(forward*throttle_value*engine_force*current_gear_ratio/3.8)
    if braking>0.01:
        apply_central_force(-forward*braking*brake_force)
    if Input.is_action_pressed("handbrake"):
        apply_central_force(-forward*signf(longitudinal)*brake_force*0.45)
    var steer_strength=steer_angle*clampf(absf(longitudinal)/8.0,0.15,1.0)
    apply_torque(Vector3.UP*steering_value*steer_strength*mass*1.2)
    # Keep the simple prototype truck upright.
    angular_velocity.x=move_toward(angular_velocity.x,0.0,delta*1.8)
    angular_velocity.z=move_toward(angular_velocity.z,0.0,delta*1.8)
    if global_position.y<0.2:
        linear_velocity.y=maxf(linear_velocity.y,-2.0)
