extends Control

signal start_game
signal quit_game

func _ready()->void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var background:=ColorRect.new()
    background.color=Color(0.035,0.055,0.075)
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(background)
    var title:=Label.new()
    title.text="TRUCKERS OF EUROPE 6"
    title.position=Vector2(0,110)
    title.size=Vector2(1280,80)
    title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size",42)
    add_child(title)
    var subtitle:=Label.new()
    subtitle.text="THE OPEN ROAD IS YOURS"
    subtitle.position=Vector2(0,185)
    subtitle.size=Vector2(1280,40)
    subtitle.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size",18)
    add_child(subtitle)
    var start:=Button.new()
    start.text="START DRIVING"
    start.position=Vector2(500,330)
    start.size=Vector2(280,64)
    start.pressed.connect(func(): start_game.emit())
    add_child(start)
    var quit:=Button.new()
    quit.text="EXIT"
    quit.position=Vector2(500,410)
    quit.size=Vector2(280,54)
    quit.pressed.connect(func(): quit_game.emit())
    add_child(quit)
