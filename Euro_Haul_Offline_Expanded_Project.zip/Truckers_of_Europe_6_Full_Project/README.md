# TRUCKERS OF EUROPE 6 — Expanded Godot prototype

Original fictional mobile trucking-simulator prototype for Godot 4.7.2. This expanded package adds modular fleet purchasing/selection data, garage paint and upgrade economy, fatigue/rest, contract selection and rewards, navigation guidance, procedural town blocks, weather states, traffic-incident fine tracking, and an audio event bus.

## Import
Open this folder in Godot 4.7.2 using Project > Import, then run `scenes/Main.tscn`. The project is source code, not an APK.

## Controls
W/Up accelerate; S/Down brake; A/D steer; Space handbrake; C camera; E engine; R rest (when stopped); T cycle fleet selection (prototype data). Touch controls are shown in the game.

## Important status
This is an expanded playable-development scaffold, not a finished commercial simulator. The map remains a compact prototype area; procedural town blocks are simple placeholder geometry; trailer is still a visual body rather than a fully articulated trailer; traffic is basic; sound event hooks need original/licensed audio assets; weather states need particle, road-material and lighting integration; navigation is guidance data rather than a complete GPS route graph. No professional truck asset pack, voice navigation, multiplayer, signed Android APK, or production QA is included.

All truck brands, names, cities/jobs presentation and assets should remain original or properly licensed. Do not use copyrighted game assets or source code from other titles.

## Added systems in this expansion
- Fleet catalogue: three fictional truck configurations, ownership and purchase validation.
- Garage: paint cycling and upgrade pricing/purchase logic; paint cycling is wired to the visible truck cab.
- Driver fatigue: fatigue rises while driving and can be reduced by resting while stopped in the service-area zone.
- Contracts: sample freight contracts with acceptance/completion state and one-shot reward API.
- Navigation: destination list and turn/distance guidance string, displayed in the HUD.
- Weather: clear/cloudy/rain/fog/storm states and rain/fog intensity values.
- Town builder: deterministic procedural placeholder building clusters for two roadside town areas.
- Traffic rules: collision incident/fine tracking API.
- Audio manager: event signal bus for future engine, horn, gear, tyre, rain and UI sound assets.

## Still not production-complete
The new systems are a mixture of integrated prototype features and extension APIs. The contract board/payout flow is not yet a full job-selection interface; truck purchase and upgrades are not yet exposed through a complete garage menu; weather values are not yet connected to rain particles, wet-road shaders or visibility effects; traffic fine tracking is not yet driven by robust collision classification; the audio bus has no bundled sound recordings; navigation does not calculate routes over a road graph. Trailer articulation/coupling, realistic suspension and steering, full AI traffic rules, a large connected multi-country map, animated driver/interior controls, and signed Android export remain future development work.
